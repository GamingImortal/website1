hello.js

let bb = 23;
console.log(bb)